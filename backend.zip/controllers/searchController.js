const db = require('../config/database');

// Search properties
exports.searchProperties = async (req, res) => {
  try {
    const { location, price, size, type } = req.query;
    
    let query = `
      SELECT p.*, u.username as owner_name 
      FROM properties p 
      LEFT JOIN users u ON p.user_id = u.id 
      WHERE 1=1
    `;
    const params = [];
    
    if (location) {
      query += ' AND p.location LIKE ?';
      params.push(`%${location}%`);
    }
    
    if (price) {
      query += ' AND p.price <= ?';
      params.push(parseFloat(price));
    }
    
    if (size) {
      query += ' AND p.size >= ?';
      params.push(parseInt(size));
    }
    
    if (type) {
      query += ' AND p.type = ?';
      params.push(type);
    }
    
    query += ' ORDER BY p.created_at DESC';
    
    const [properties] = await db.query(query, params);
    
    res.json({
      success: true,
      count: properties.length,
      properties
    });
  } catch (error) {
    console.error('Search error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during search'
    });
  }
};

// Get properties by type
exports.getPropertiesByType = async (req, res) => {
  try {
    const type = req.params.type;
    
    const [properties] = await db.query(
      `SELECT p.*, u.username as owner_name 
       FROM properties p 
       LEFT JOIN users u ON p.user_id = u.id 
       WHERE p.type = ? 
       ORDER BY p.created_at DESC`,
      [type]
    );
    
    res.json({
      success: true,
      count: properties.length,
      properties
    });
  } catch (error) {
    console.error('Get by type error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching properties'
    });
  }
};

// Get featured properties (highest rated)
exports.getFeaturedProperties = async (req, res) => {
  try {
    const [properties] = await db.query(
      `SELECT p.*, u.username as owner_name 
       FROM properties p 
       LEFT JOIN users u ON p.user_id = u.id 
       WHERE p.average_rating >= 4 
       ORDER BY p.average_rating DESC, p.review_count DESC 
       LIMIT 10`
    );
    
    res.json({
      success: true,
      count: properties.length,
      properties
    });
  } catch (error) {
    console.error('Get featured error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching featured properties'
    });
  }
};