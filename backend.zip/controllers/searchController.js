const db = require('../config/database');

exports.searchProperties = async (req, res) => {
  try {
    // Clean and normalize search parameters
    const location = req.query.location ? req.query.location.trim().toLowerCase() : null;
    const price = req.query.price ? parseFloat(req.query.price) : null;
    const size = req.query.size ? parseInt(req.query.size) : null;
    const type = req.query.type ? req.query.type.trim().toLowerCase() : null;
    
    console.log('🔍 SEARCH PARAMS:', { location, price, size, type });
    
    let query = `
      SELECT p.*, u.name as owner_name 
      FROM properties p 
      LEFT JOIN users u ON p.user_id = u.id 
      WHERE 1=1
    `;
    const params = [];
    
    if (location) {
      query += ' AND LOWER(p.location) LIKE ?';
      params.push(`%${location}%`);
    }
    
    if (price && !isNaN(price)) {
      query += ' AND p.price <= ?';
      params.push(price);
    }
    
    if (size && !isNaN(size)) {
      query += ' AND p.size >= ?';
      params.push(size);
    }
    
    if (type) {
      query += ' AND LOWER(p.type) = ?';
      params.push(type);
    }
    
    query += ' ORDER BY p.created_at DESC';
    
    console.log('📝 SQL:', query);
    console.log('🔢 Params:', params);
    
    const [properties] = await db.query(query, params);
    
    console.log('✅ Found:', properties.length, 'properties');
    
    res.json({
      success: true,
      count: properties.length,
      properties
    });
  } catch (error) {
    console.error('❌ Search error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during search'
    });
  }
};

exports.getPropertiesByType = async (req, res) => {
  try {
    const type = req.params.type ? req.params.type.trim().toLowerCase() : '';
    
    const [properties] = await db.query(
      `SELECT p.*, u.name as owner_name 
       FROM properties p 
       LEFT JOIN users u ON p.user_id = u.id 
       WHERE LOWER(p.type) = ? 
       ORDER BY p.created_at DESC`,
      [type]
    );
    
    res.json({
      success: true,
      count: properties.length,
      properties
    });
  } catch (error) {
    console.error('Get by type error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching properties'
    });
  }
};

exports.getFeaturedProperties = async (req, res) => {
  try {
    const [properties] = await db.query(
      `SELECT p.*, u.name as owner_name 
       FROM properties p 
       LEFT JOIN users u ON p.user_id = u.id 
       WHERE p.average_rating >= 4 
       ORDER BY p.average_rating DESC, p.review_count DESC 
       LIMIT 10`
    );
    
    res.json({
      success: true,
      count: properties.length,
      properties
    });
  } catch (error) {
    console.error('Get featured error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching featured properties'
    });
  }
};