const db = require('../config/database');
const path = require('path');

// Create new property listing
exports.createProperty = async (req, res) => {
  try {
    const { 
      'property-location': location, 
      'property-price': price, 
      'property-size': size,
      'property-type': type,
      'property-bedrooms': bedrooms,
      'property-description': description
    } = req.body;

    const userId = req.user.id;
    
    // Check if image was uploaded
    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: 'Please upload a property image'
      });
    }

    const imagePath = `/uploads/properties/${req.file.filename}`;
    
    // Insert property
    const [result] = await db.query(
      `INSERT INTO properties 
      (user_id, location, price, size, type, bedrooms, description, image_url, created_at) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
      [userId, location, price, size, type, bedrooms, description, imagePath]
    );
    
    // Get the created property
    const [properties] = await db.query(
      'SELECT * FROM properties WHERE id = ?',
      [result.insertId]
    );
    
    res.status(201).json({
      success: true,
      message: 'Property listed successfully',
      property: properties[0]
    });
  } catch (error) {
    console.error('Create property error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while creating property'
    });
  }
};

// Get all properties
exports.getAllProperties = async (req, res) => {
  try {
    const [properties] = await db.query(
      `SELECT p.*, u.name as owner_name 
       FROM properties p 
       LEFT JOIN users u ON p.user_id = u.id 
       ORDER BY p.created_at DESC`
    );
    
    res.json({
      success: true,
      count: properties.length,
      properties
    });
  } catch (error) {
    console.error('Get properties error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching properties'
    });
  }
};

// Get single property
exports.getProperty = async (req, res) => {
  try {
    const propertyId = req.params.id;
    
    const [properties] = await db.query(
      `SELECT p.*, u.username as owner_name 
       FROM properties p 
       LEFT JOIN users u ON p.user_id = u.id 
       WHERE p.id = ?`,
      [propertyId]
    );
    
    if (properties.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Property not found'
      });
    }
    
    res.json({
      success: true,
      property: properties[0]
    });
  } catch (error) {
    console.error('Get property error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching property'
    });
  }
};

// Get user's properties
exports.getUserProperties = async (req, res) => {
  try {
    const userId = req.user.id;
    
    const [properties] = await db.query(
      'SELECT * FROM properties WHERE user_id = ? ORDER BY created_at DESC',
      [userId]
    );
    
    res.json({
      success: true,
      count: properties.length,
      properties
    });
  } catch (error) {
    console.error('Get user properties error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching user properties'
    });
  }
};

// Update property
exports.updateProperty = async (req, res) => {
  try {
    const propertyId = req.params.id;
    const userId = req.user.id;
    const updateData = req.body;
    
    // Check if property belongs to user
    const [properties] = await db.query(
      'SELECT * FROM properties WHERE id = ? AND user_id = ?',
      [propertyId, userId]
    );
    
    if (properties.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Property not found or unauthorized'
      });
    }
    
    // Build update query
    const fields = [];
    const values = [];
    
    Object.keys(updateData).forEach(key => {
      if (updateData[key] !== undefined) {
        fields.push(`${key} = ?`);
        values.push(updateData[key]);
      }
    });
    
    if (fields.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No data provided to update'
      });
    }
    
    values.push(propertyId, userId);
    
    const query = `UPDATE properties SET ${fields.join(', ')} WHERE id = ? AND user_id = ?`;
    
    await db.query(query, values);
    
    // Get updated property
    const [updatedProperties] = await db.query(
      'SELECT * FROM properties WHERE id = ?',
      [propertyId]
    );
    
    res.json({
      success: true,
      message: 'Property updated successfully',
      property: updatedProperties[0]
    });
  } catch (error) {
    console.error('Update property error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while updating property'
    });
  }
};

// Delete property
exports.deleteProperty = async (req, res) => {
  try {
    const propertyId = req.params.id;
    const userId = req.user.id;
    
    // Check if property belongs to user
    const [properties] = await db.query(
      'SELECT * FROM properties WHERE id = ? AND user_id = ?',
      [propertyId, userId]
    );
    
    if (properties.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Property not found or unauthorized'
      });
    }
    
    await db.query('DELETE FROM properties WHERE id = ? AND user_id = ?', [propertyId, userId]);
    
    res.json({
      success: true,
      message: 'Property deleted successfully'
    });
  } catch (error) {
    console.error('Delete property error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while deleting property'
    });
  }
};