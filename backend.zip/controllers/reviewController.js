const db = require('../config/database');

// Create review
exports.createReview = async (req, res) => {
  try {
    const { property_id, rating, review_text } = req.body;
    const userId = req.user.id;
    
    // Validation
    if (!property_id || !rating || rating < 1 || rating > 5) {
      return res.status(400).json({
        success: false,
        message: 'Please provide valid property ID and rating (1-5)'
      });
    }
    
    // Check if property exists
    const [properties] = await db.query(
      'SELECT id FROM properties WHERE id = ?',
      [property_id]
    );
    
    if (properties.length === 0) {
      return res.status(404).json({
        success: false,
        message: 'Property not found'
      });
    }
    
    // Check if user already reviewed this property
    const [existingReviews] = await db.query(
      'SELECT id FROM reviews WHERE user_id = ? AND property_id = ?',
      [userId, property_id]
    );
    
    if (existingReviews.length > 0) {
      return res.status(400).json({
        success: false,
        message: 'You have already reviewed this property'
      });
    }
    
    // Insert review
    const [result] = await db.query(
      `INSERT INTO reviews (user_id, property_id, rating, review_text, created_at) 
       VALUES (?, ?, ?, ?, NOW())`,
      [userId, property_id, rating, review_text || '']
    );
    
    // Update property average rating
    await this.updatePropertyRating(property_id);
    
    // Get the created review with user info
    const [reviews] = await db.query(
      `SELECT r.*, u.name 
       FROM reviews r 
       LEFT JOIN users u ON r.user_id = u.id 
       WHERE r.id = ?`,
      [result.insertId]
    );
    
    res.status(201).json({
      success: true,
      message: 'Review submitted successfully',
      review: reviews[0]
    });
  } catch (error) {
    console.error('Create review error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while creating review'
    });
  }
};

// Update property average rating
exports.updatePropertyRating = async (propertyId) => {
  try {
    const [reviews] = await db.query(
      'SELECT AVG(rating) as avg_rating, COUNT(*) as review_count FROM reviews WHERE property_id = ?',
      [propertyId]
    );
    
    if (reviews[0].review_count > 0) {
      await db.query(
        'UPDATE properties SET average_rating = ?, review_count = ? WHERE id = ?',
        [reviews[0].avg_rating, reviews[0].review_count, propertyId]
      );
    }
  } catch (error) {
    console.error('Update property rating error:', error);
  }
};

// Get reviews for a property
exports.getPropertyReviews = async (req, res) => {
  try {
    const propertyId = req.params.propertyId;
    
    const [reviews] = await db.query(
      `SELECT r.*, u.name 
       FROM reviews r 
       LEFT JOIN users u ON r.user_id = u.id 
       WHERE r.property_id = ? 
       ORDER BY r.created_at DESC`,
      [propertyId]
    );
    
    res.json({
      success: true,
      count: reviews.length,
      reviews
    });
  } catch (error) {
    console.error('Get reviews error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching reviews'
    });
  }
};

// Get all reviews
exports.getAllReviews = async (req, res) => {
  try {
    const [reviews] = await db.query(
      `SELECT r.*, u.name, p.location as property_location 
       FROM reviews r 
       LEFT JOIN users u ON r.user_id = u.id 
       LEFT JOIN properties p ON r.property_id = p.id 
       ORDER BY r.created_at DESC 
       LIMIT 50`
    );
    
    res.json({
      success: true,
      count: reviews.length,
      reviews
    });
  } catch (error) {
    console.error('Get all reviews error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching reviews'
    });
  }
};