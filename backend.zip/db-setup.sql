-- db-setup.sql
-- Run this as a privileged MySQL user (for example `root`) to create the database
-- and an application user. Edit the username/password as desired.

CREATE DATABASE IF NOT EXISTS ghorbari_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

CREATE USER IF NOT EXISTS 'ghorbari'@'localhost' IDENTIFIED BY 'ghorbari_pass';
GRANT ALL PRIVILEGES ON ghorbari_db.* TO 'ghorbari'@'localhost';
FLUSH PRIVILEGES;

-- Optional: create sample tables (adjust schema to match your models)
-- CREATE TABLE ghorbari_db.users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(255), email VARCHAR(255));