# Ghorbari Backend

Quick instructions to run the backend and optionally serve the frontend static files.

Prerequisites:
- Node.js (>=18 recommended)
- MySQL database ready and reachable

Setup:
1. Copy `.env.example` to `.env` and fill database credentials.
2. Install dependencies:

```bash
npm install
```

Run backend in development:

```bash
npm run dev
```

Run backend normally:

```bash
npm start
```

To serve the frontend from the backend (useful for a single server deployment):
1. Set `SERVE_FRONTEND=true` in your `.env`.
2. Ensure the sibling folder `ghorbari-frontend` exists next to the backend folder.
3. Start the server. Static files will be served from `../ghorbari-frontend`.

Notes:
- The frontend expects the API root at `http://localhost:5000/api` by default (`API_BASE_URL`).
- If you host the frontend on a different origin, set `FRONTEND_URL` in `.env` to allow CORS.

Database setup (recommended):

1. Create the DB and a dedicated user (run as a privileged MySQL user, e.g., `root`):

```bash
# From the backend folder, run the SQL file we added:
mysql -u root -p < db-setup.sql
```

2. Verify the `.env` values match your DB credentials. We added a `.env` example and a local `.env` in the repository.

Troubleshooting:
- If you see `Access denied` when the server starts, ensure the DB user and password are correct and that the user
	has privileges on the `DB_NAME` database and can connect from the host.
- If you prefer not to run SQL from the command line, run the SQL statements inside `db-setup.sql` using any DB client.