-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 15, 2025 at 09:25 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ghorbari_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `properties`
--

CREATE TABLE `properties` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `location` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `size` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `bedrooms` int(11) DEFAULT 1,
  `description` text DEFAULT NULL,
  `image_url` varchar(500) DEFAULT NULL,
  `average_rating` decimal(3,2) DEFAULT 0.00,
  `review_count` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `properties`
--

INSERT INTO `properties` (`id`, `user_id`, `location`, `price`, `size`, `type`, `bedrooms`, `description`, `image_url`, `average_rating`, `review_count`, `created_at`, `updated_at`) VALUES
(1, 1, 'Dhaka', 13000.00, 1200, 'apartment', 2, '2 BHK, 1 Drawing, 1 Dinning, 2 Balcony, 2 Bathroom. Located in a peaceful area with good security.', '/uploads/properties/sample1.jpg', 0.00, 0, '2025-12-15 17:29:16', '2025-12-15 17:29:16'),
(2, 2, 'Chattogram', 17000.00, 1500, 'house', 3, '3 BHK, 1 Drawing, 1 Dinning, 2 Balcony, 3 Bathroom. Perfect for family living with garden.', '/uploads/properties/sample2.jpg', 0.00, 0, '2025-12-15 17:29:16', '2025-12-15 17:29:16'),
(3, 3, 'Chattogram', 30000.00, 1500, 'villa', 5, '5 BHK, 1 Drawing, 1 Dinning, 3 Balcony, 4 Bathroom. Luxury villa with modern amenities.', '/uploads/properties/sample3.jpg', 0.00, 0, '2025-12-15 17:29:16', '2025-12-15 17:29:16'),
(4, 1, 'Dhaka', 40000.00, 2500, 'studio', 1, 'Luxury studio apartment in prime location with beautiful view. Fully furnished.', '/uploads/properties/sample4.jpg', 0.00, 0, '2025-12-15 17:29:16', '2025-12-15 17:29:16');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `property_id` int(11) NOT NULL,
  `rating` int(11) NOT NULL CHECK (`rating` >= 1 and `rating` <= 5),
  `review_text` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `user_id`, `property_id`, `rating`, `review_text`, `created_at`) VALUES
(1, 2, 1, 5, 'Great apartment! Loved the location and amenities. The landlord was very helpful.', '2025-12-15 17:29:16'),
(2, 3, 1, 4, 'Nice place, good amenities. Would recommend for small families.', '2025-12-15 17:29:16'),
(3, 1, 2, 5, 'Beautiful house, highly recommended! The garden is perfect for children.', '2025-12-15 17:29:16'),
(4, 3, 2, 4, 'Good value for money. The neighborhood is quiet and safe.', '2025-12-15 17:29:16'),
(5, 1, 3, 5, 'Amazing villa! Perfect for families. Everything was as described.', '2025-12-15 17:29:16'),
(6, 2, 4, 3, 'Studio is smaller than expected but good for single person.', '2025-12-15 17:29:16');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(150) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `password_hash` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`, `updated_at`, `password_hash`) VALUES
(1, 'John Doe', 'john@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MrqKJ1Yc6Hj7.8UEl.JO2eB.8Z8qWtO', '2025-12-15 17:29:16', '2025-12-15 17:29:16', NULL),
(2, 'Jane Smith', 'jane@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MrqKJ1Yc6Hj7.8UEl.JO2eB.8Z8qWtO', '2025-12-15 17:29:16', '2025-12-15 17:29:16', NULL),
(3, 'Bob Wilson', 'bob@example.com', '$2a$10$N9qo8uLOickgx2ZMRZoMy.MrqKJ1Yc6Hj7.8UEl.JO2eB.8Z8qWtO', '2025-12-15 17:29:16', '2025-12-15 17:29:16', NULL),
(4, 'sakib', 'sakibprome8@gmail.com', '', '2025-12-15 20:24:23', '2025-12-15 20:24:23', '$2b$10$xRRUmxGM8c0U5QnAPmef4.eJJP6G842C/2UTHdTr7jBKvka5/Fl.y');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `properties`
--
ALTER TABLE `properties`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `idx_location` (`location`),
  ADD KEY `idx_price` (`price`),
  ADD KEY `idx_type` (`type`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_property` (`user_id`,`property_id`),
  ADD KEY `idx_property_id` (`property_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `properties`
--
ALTER TABLE `properties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `properties`
--
ALTER TABLE `properties`
  ADD CONSTRAINT `properties_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `reviews`
--
ALTER TABLE `reviews`
  ADD CONSTRAINT `reviews_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `reviews_ibfk_2` FOREIGN KEY (`property_id`) REFERENCES `properties` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
