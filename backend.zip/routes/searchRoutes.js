const express = require('express');
const router = express.Router();
const { 
  searchProperties, 
  getPropertiesByType,
  getFeaturedProperties 
} = require('../controllers/searchController');

// Search routes
router.get('/', searchProperties);
router.get('/type/:type', getPropertiesByType);
router.get('/featured', getFeaturedProperties);

module.exports = router;