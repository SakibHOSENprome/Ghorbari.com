const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../config/database');

router.post('/register', async (req, res) => {
  console.log('=== REGISTRATION ATTEMPT ===');
  console.log('Request body:', req.body);
  
  let connection;
  try {
    const { name, email, password } = req.body;
    
    console.log('1. Validating fields...');
    if (!name || !email || !password) {
      return res.status(400).json({ 
        success: false, 
        message: 'Please provide all fields' 
      });
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ 
        success: false, 
        message: 'Please provide a valid email address' 
      });
    }
    
    console.log('2. Checking if email exists:', email);
    
    // Method 1: Using promise pool directly (recommended)
    const [existing] = await db.query(
      'SELECT id FROM users WHERE email = ?', 
      [email]
    );
    
    // OR Method 2: If you want to use execute specifically:
    // const [existing] = await db.execute(
    //   'SELECT id FROM users WHERE email = ?', 
    //   [email]
    // );
    
    if (existing.length > 0) {
      console.log('Email already exists');
      return res.status(400).json({ 
        success: false, 
        message: 'User already exists' 
      });
    }
    
    console.log('3. Hashing password...');
    const hashedPassword = await bcrypt.hash(password, 10);
    
    console.log('4. Inserting user into database...');
    const [result] = await db.query(
      'INSERT INTO users (name, email, password_hash, created_at) VALUES (?, ?, ?, NOW())',
      [name, email, hashedPassword]
    );
    
    console.log('✅ SUCCESS! User ID:', result.insertId);
    
    // Generate JWT token for immediate login after registration
    const token = jwt.sign(
      { userId: result.insertId, email: email },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );
    
    res.status(201).json({ 
      success: true, 
      message: 'User registered successfully',
      userId: result.insertId,
      token: token,
      user: {
        id: result.insertId,
        name: name,
        email: email
      }
    });
    
  } catch (error) {
    console.error('❌ DATABASE ERROR:', error.message);
    console.error('Error code:', error.code);
    console.error('SQL Message:', error.sqlMessage);
    
    // Check for specific MySQL duplicate entry error
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(400).json({ 
        success: false, 
        message: 'User already exists' 
      });
    }
    
    res.status(500).json({ 
      success: false, 
      message: 'Server error during registration'
    });
  }
});

// Add login endpoint
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    
    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide email and password'
      });
    }
    
    const [users] = await db.query(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );
    
    if (users.length === 0) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }
    
    const user = users[0];
    const isValidPassword = await bcrypt.compare(password, user.password_hash);
    
    if (!isValidPassword) {
      return res.status(401).json({
        success: false,
        message: 'Invalid credentials'
      });
    }
    
    const token = jwt.sign(
      { userId: user.id, email: user.email },
      process.env.JWT_SECRET || 'your-secret-key',
      { expiresIn: '24h' }
    );
    
    res.json({
      success: true,
      message: 'Login successful',
      token: token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email
      }
    });
    
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error during login'
    });
  }
});

// Test endpoint to check database connection
router.get('/test-db', async (req, res) => {
  try {
    const [results] = await db.query('SELECT 1 as test');
    res.json({
      success: true,
      message: 'Database connection successful',
      data: results
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'Database connection failed',
      error: error.message
    });
  }
});

module.exports = router;