const express = require('express');
const router = express.Router();
const { 
  createProperty, 
  getAllProperties, 
  getProperty, 
  getUserProperties,
  updateProperty,
  deleteProperty 
} = require('../controllers/propertyController');
const auth = require('../middleware/auth');
const upload = require('../middleware/upload');

// Public routes
router.get('/', getAllProperties);
router.get('/:id', getProperty);

// Protected routes (require authentication)
router.post('/', auth, upload, createProperty);
router.get('/user/my-properties', auth, getUserProperties);
router.put('/:id', auth, updateProperty);
router.delete('/:id', auth, deleteProperty);

module.exports = router;