const express = require('express');
const router = express.Router();
const { 
  createReview, 
  getPropertyReviews,
  getAllReviews 
} = require('../controllers/reviewController');
const auth = require('../middleware/auth');

// Public routes
router.get('/property/:propertyId', getPropertyReviews);
router.get('/', getAllReviews);

// Protected routes
router.post('/', auth, createReview);

module.exports = router;