// scripts.js - Common JavaScript functions for Ghorbari.com
// Determine API base: when frontend is served from the backend (same origin/port 5000),
// use a relative path (`/api`). Otherwise default to the local backend URL.
const API_BASE_URL = (function() {
    try {
        const origin = window.location.origin || '';
        if (origin.includes(':5000')) return '/api';
    } catch (e) {}
    return 'http://localhost:5000/api';  // ← CHANGED THIS LINE
})();

// Get token from localStorage
function getToken() {
    return localStorage.getItem('token');
}

// Set token in localStorage
function setToken(token) {
    localStorage.setItem('token', token);
}

// Remove token from localStorage (logout)
function removeToken() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    window.location.href = 'login.html';
}

// Get current user from localStorage
function getCurrentUser() {
    const user = localStorage.getItem('user');
    return user ? JSON.parse(user) : null;
}

// Set current user in localStorage
function setCurrentUser(user) {
    localStorage.setItem('user', JSON.stringify(user));
}

// Check if user is logged in
function isLoggedIn() {
    return getToken() !== null;
}

// Show notification
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        background: ${type === 'success' ? '#4CAF50' : '#f44336'};
        color: white;
        border-radius: 5px;
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add CSS for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    @keyframes slideOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
    }
`;
document.head.appendChild(style);

// Update navigation based on login status
function updateNavigation() {
    const user = getCurrentUser();
    const nav = document.querySelector('nav ul');
    
    if (!nav) return;
    
    if (user) {
        // User is logged in
        const loginLink = nav.querySelector('a[href="login.html"]');
        const registerLink = nav.querySelector('a[href="register.html"]');
        
        if (loginLink) {
            loginLink.parentElement.innerHTML = `
                <li>
                    <a href="#" id="logout">Logout (${user.username})</a>
                </li>
            `;
            
            document.getElementById('logout').addEventListener('click', removeToken);
        }
        
        if (registerLink) {
            registerLink.parentElement.remove();
        }
    }
}

// Initialize navigation on page load
document.addEventListener('DOMContentLoaded', updateNavigation);